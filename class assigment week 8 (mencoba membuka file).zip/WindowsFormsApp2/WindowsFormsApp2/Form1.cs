﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        List<string> Data = new List<string>();
        int banyak = 0;
        int banyakbaru = -1;
        public Form1()
        {
            InitializeComponent();
        }
        OpenFileDialog ofd = new OpenFileDialog();
        private void button_File_Click(object sender, EventArgs e)
        {
            
            ofd.InitialDirectory = "Y:\\";
            ofd.ShowDialog();

            StreamReader sr = new StreamReader(ofd.FileName);
            string baris = sr.ReadLine();
            while (baris != null)
            {
                Data.Add(baris);
                baris = sr.ReadLine();
                banyakbaru++;
            }
            sr.Close();
        }

        private void button_Lihat_Click(object sender, EventArgs e)
        {
            
            string[] variable = Data[0].Split(';') ;
            textBox_Nama.Text = variable[0];
            textBox_Alamat.Text = variable[1];
            textBox_NoTelp.Text = variable[2];
            button_Simpan.Visible = false;
            button_Prev.Visible = true;
            button_Next.Visible = true;
            button_Kembali.Visible = true;
            textBox_Nama.Enabled = false;
            textBox_Alamat.Enabled = false;
            textBox_NoTelp.Enabled = false;
            button_Lihat.Visible = false;
        }

        private void button_Next_Click(object sender, EventArgs e)
        {
            if (banyak < Data.Count-1)
            {
                banyak += 1;
            }
            
           
            // sr = new StreamReader("Y:\\cobacoba.txt");
            string[] variable = Data[banyak].Split(';');
            textBox_Nama.Text = variable[0];
            textBox_Alamat.Text = variable[1];
            textBox_NoTelp.Text = variable[2];
            button_Simpan.Visible = false;
            button_Prev.Visible = true;
            button_Next.Visible = true;
            button_Kembali.Visible = true;
            textBox_Nama.Enabled = false;
            textBox_Alamat.Enabled = false;
            textBox_NoTelp.Enabled = false;
            button_Lihat.Visible = false;
        }

        private void button_Prev_Click(object sender, EventArgs e)
        {
            if (banyak == 0)
            {
                banyak = 0;
            }
            else
            {
                banyak = banyak - 1;
            }
           
            string[] variable = Data[banyak].Split(';');
            textBox_Nama.Text = variable[0];
            textBox_Alamat.Text = variable[1];
            textBox_NoTelp.Text = variable[2];
            button_Simpan.Visible = false;
            button_Prev.Visible = true;
            button_Next.Visible = true;
            button_Kembali.Visible = true;
            textBox_Nama.Enabled = false;
            textBox_Alamat.Enabled = false;
            textBox_NoTelp.Enabled = false;
            button_Lihat.Visible = false;
        }

        private void button_Kembali_Click(object sender, EventArgs e)
        {
            button_Simpan.Visible = true;
            button_Prev.Visible = false;
            button_Next.Visible = false;
            button_Kembali.Visible = false;
            textBox_Nama.Enabled = true;
            textBox_Alamat.Enabled = true;
            textBox_NoTelp.Enabled = true;
            button_Lihat.Visible = true;
            textBox_Nama.Clear();
            textBox_Alamat.Clear();
            textBox_NoTelp.Clear();
        }

        private void button_Simpan_Click(object sender, EventArgs e)
        {
            Data.Add(textBox_Nama.Text + ";" + textBox_Alamat.Text + ";" + textBox_NoTelp.Text);
            StreamWriter sw = new StreamWriter("Y:\\cobacoba.txt");
            foreach (string d in Data)
            {
                sw.WriteLine(d);
            }
            sw.Close();
            textBox_Nama.Clear();
            textBox_Alamat.Clear();
            textBox_NoTelp.Clear();
        }
    }
}
