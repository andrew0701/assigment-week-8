﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Nama = new System.Windows.Forms.Label();
            this.lb_NoTelp = new System.Windows.Forms.Label();
            this.lb_Alamat = new System.Windows.Forms.Label();
            this.textBox_Nama = new System.Windows.Forms.TextBox();
            this.textBox_Alamat = new System.Windows.Forms.TextBox();
            this.textBox_NoTelp = new System.Windows.Forms.TextBox();
            this.button_File = new System.Windows.Forms.Button();
            this.button_Simpan = new System.Windows.Forms.Button();
            this.button_Lihat = new System.Windows.Forms.Button();
            this.button_Prev = new System.Windows.Forms.Button();
            this.button_Next = new System.Windows.Forms.Button();
            this.button_Kembali = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_Nama
            // 
            this.lb_Nama.AutoSize = true;
            this.lb_Nama.Location = new System.Drawing.Point(62, 56);
            this.lb_Nama.Name = "lb_Nama";
            this.lb_Nama.Size = new System.Drawing.Size(68, 25);
            this.lb_Nama.TabIndex = 0;
            this.lb_Nama.Text = "Nama";
            // 
            // lb_NoTelp
            // 
            this.lb_NoTelp.AutoSize = true;
            this.lb_NoTelp.Location = new System.Drawing.Point(62, 144);
            this.lb_NoTelp.Name = "lb_NoTelp";
            this.lb_NoTelp.Size = new System.Drawing.Size(87, 25);
            this.lb_NoTelp.TabIndex = 1;
            this.lb_NoTelp.Text = "No Telp";
            // 
            // lb_Alamat
            // 
            this.lb_Alamat.AutoSize = true;
            this.lb_Alamat.Location = new System.Drawing.Point(62, 99);
            this.lb_Alamat.Name = "lb_Alamat";
            this.lb_Alamat.Size = new System.Drawing.Size(78, 25);
            this.lb_Alamat.TabIndex = 2;
            this.lb_Alamat.Text = "Alamat";
            // 
            // textBox_Nama
            // 
            this.textBox_Nama.Location = new System.Drawing.Point(181, 56);
            this.textBox_Nama.Name = "textBox_Nama";
            this.textBox_Nama.Size = new System.Drawing.Size(281, 31);
            this.textBox_Nama.TabIndex = 3;
            // 
            // textBox_Alamat
            // 
            this.textBox_Alamat.Location = new System.Drawing.Point(181, 99);
            this.textBox_Alamat.Name = "textBox_Alamat";
            this.textBox_Alamat.Size = new System.Drawing.Size(281, 31);
            this.textBox_Alamat.TabIndex = 4;
            // 
            // textBox_NoTelp
            // 
            this.textBox_NoTelp.Location = new System.Drawing.Point(181, 144);
            this.textBox_NoTelp.Name = "textBox_NoTelp";
            this.textBox_NoTelp.Size = new System.Drawing.Size(281, 31);
            this.textBox_NoTelp.TabIndex = 5;
            // 
            // button_File
            // 
            this.button_File.Location = new System.Drawing.Point(533, 56);
            this.button_File.Name = "button_File";
            this.button_File.Size = new System.Drawing.Size(123, 48);
            this.button_File.TabIndex = 6;
            this.button_File.Text = "File";
            this.button_File.UseVisualStyleBackColor = true;
            this.button_File.Click += new System.EventHandler(this.button_File_Click);
            // 
            // button_Simpan
            // 
            this.button_Simpan.Location = new System.Drawing.Point(99, 212);
            this.button_Simpan.Name = "button_Simpan";
            this.button_Simpan.Size = new System.Drawing.Size(105, 49);
            this.button_Simpan.TabIndex = 7;
            this.button_Simpan.Text = "Simpan";
            this.button_Simpan.UseVisualStyleBackColor = true;
            this.button_Simpan.Click += new System.EventHandler(this.button_Simpan_Click);
            // 
            // button_Lihat
            // 
            this.button_Lihat.Location = new System.Drawing.Point(225, 212);
            this.button_Lihat.Name = "button_Lihat";
            this.button_Lihat.Size = new System.Drawing.Size(105, 49);
            this.button_Lihat.TabIndex = 8;
            this.button_Lihat.Text = "Lihat";
            this.button_Lihat.UseVisualStyleBackColor = true;
            this.button_Lihat.Click += new System.EventHandler(this.button_Lihat_Click);
            // 
            // button_Prev
            // 
            this.button_Prev.Location = new System.Drawing.Point(121, 277);
            this.button_Prev.Name = "button_Prev";
            this.button_Prev.Size = new System.Drawing.Size(105, 49);
            this.button_Prev.TabIndex = 9;
            this.button_Prev.Text = "Prev";
            this.button_Prev.UseVisualStyleBackColor = true;
            this.button_Prev.Visible = false;
            this.button_Prev.Click += new System.EventHandler(this.button_Prev_Click);
            // 
            // button_Next
            // 
            this.button_Next.Location = new System.Drawing.Point(243, 277);
            this.button_Next.Name = "button_Next";
            this.button_Next.Size = new System.Drawing.Size(105, 49);
            this.button_Next.TabIndex = 10;
            this.button_Next.Text = "Next";
            this.button_Next.UseVisualStyleBackColor = true;
            this.button_Next.Visible = false;
            this.button_Next.Click += new System.EventHandler(this.button_Next_Click);
            // 
            // button_Kembali
            // 
            this.button_Kembali.Location = new System.Drawing.Point(370, 277);
            this.button_Kembali.Name = "button_Kembali";
            this.button_Kembali.Size = new System.Drawing.Size(105, 49);
            this.button_Kembali.TabIndex = 11;
            this.button_Kembali.Text = "Kembali";
            this.button_Kembali.UseVisualStyleBackColor = true;
            this.button_Kembali.Visible = false;
            this.button_Kembali.Click += new System.EventHandler(this.button_Kembali_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2035, 1077);
            this.Controls.Add(this.button_Kembali);
            this.Controls.Add(this.button_Next);
            this.Controls.Add(this.button_Prev);
            this.Controls.Add(this.button_Lihat);
            this.Controls.Add(this.button_Simpan);
            this.Controls.Add(this.button_File);
            this.Controls.Add(this.textBox_NoTelp);
            this.Controls.Add(this.textBox_Alamat);
            this.Controls.Add(this.textBox_Nama);
            this.Controls.Add(this.lb_Alamat);
            this.Controls.Add(this.lb_NoTelp);
            this.Controls.Add(this.lb_Nama);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Nama;
        private System.Windows.Forms.Label lb_NoTelp;
        private System.Windows.Forms.Label lb_Alamat;
        private System.Windows.Forms.TextBox textBox_Nama;
        private System.Windows.Forms.TextBox textBox_Alamat;
        private System.Windows.Forms.TextBox textBox_NoTelp;
        private System.Windows.Forms.Button button_File;
        private System.Windows.Forms.Button button_Simpan;
        private System.Windows.Forms.Button button_Lihat;
        private System.Windows.Forms.Button button_Prev;
        private System.Windows.Forms.Button button_Next;
        private System.Windows.Forms.Button button_Kembali;
    }
}

